import React, { Component } from "react";

export class AboutUS extends Component {
  render() {
    return (
      <div>
        <h1>AboutUS page</h1>
      </div>
    );
  }
}

export default AboutUS;
